package geekycamp.jaxrs;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Booking {
	
	public enum QualityClass {
		ECONOMY("Economy"),
		STANDARD("Standard"),
		QUALITY("Quality"),
		LUXURY("Luxury");
		
		private String str;
		
		QualityClass(String str) {
			this.str = str;
		}
		
		public static QualityClass get(int i) {
			switch(i) {
			case 1: return ECONOMY;
			case 2: return STANDARD;
			case 3: return QUALITY;
			case 4: return LUXURY;
			default: return ECONOMY;
			}	
		}
		

		public String toString() {
			return this.str;
		}
	}
	
	private String name;
	private String phone;
	private String dateFrom;
	private String dateTo;
	private int n_rooms;
	private QualityClass qual;
	private boolean roomService;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public void setDateFrom(String date) {
		this.dateFrom = date;
	}
	public void setDateTo(String date) {
		this.dateTo = date;
	}
	
	public String getDateFrom() {
		return this.dateFrom;
	}
	
	public String getDateTo() {
		return this.dateTo;
	}
	
	public int getN_rooms() {
		return n_rooms;
	}
	public void setN_rooms(int n_rooms) {
		this.n_rooms = n_rooms;
	}
	public QualityClass getQual() {
		return qual;
	}
	public void setQual(QualityClass qual) {
		this.qual = qual;
	}
	public boolean isRoomService() {
		return roomService;
	}
	public void setRoomService(boolean roomService) {
		this.roomService = roomService;
	}
	
	
	public String toString() {
		StringBuilder sb = new StringBuilder("Booking:");
		sb.append("\n\tName: " + name);
		sb.append("\n\tPhone: " + phone);
		sb.append("\n\tFrom: " + dateFrom);
		sb.append("\n\tTo: " + dateTo);
		sb.append("\n\tNumber of people: " + n_rooms);
		sb.append("\n\tQuality: " + qual.toString());
		sb.append("\n\tRoom Service: " + roomService + "\n");
		return sb.toString();
	}
}
