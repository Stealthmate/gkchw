package geekycamp.jaxrs;

import java.io.BufferedReader;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.Request;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Produces;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.codec.binary.StringUtils;

import javax.ws.rs.core.Response.Status;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;

@Path("/hotel")
public class Home {
	
	public static final String SERVER_DIR = "";
	public static final java.nio.file.Path SERVER_PATH = (java.nio.file.Path) Paths.get(SERVER_DIR);
	public static final java.nio.file.Path INDEX_HTML_PATH = Paths.get(SERVER_PATH.toString(), "index.html");
	private static boolean logged_in = false;
	private static ArrayList<Booking> bookings = new ArrayList<>();
	
	public static String getFile(String filepath) throws IOException {
		return new String(Files.readAllBytes(Paths.get(filepath)), StandardCharsets.UTF_8);
	}
	public static String getFile(java.nio.file.Path filepath) throws IOException {
		return new String(Files.readAllBytes(filepath), StandardCharsets.UTF_8);
	}
	
	public void loadTeachers() throws JsonParseException, JsonMappingException, IOException {
	}
	
	public Home() {

	}
	
	private String getfile(String path) throws IOException {
		List<String> lines = Files.readAllLines(Paths.get(path));
		StringBuilder whole = new StringBuilder();
		for(String s : lines) whole.append(s + "\n");
		return whole.toString();
	}
	
	@GET
	@Produces("text/html")
	public Response getIndex() {
		try {
			return Response.seeOther(new URI("hotel/index.html")).build();
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}


	@GET
	@Path("styles/{file}")
	@Produces("text/css")
	public Response getFileRequested(@PathParam("file") String filepath) {
		try {
			String f = getfile("styles/" + filepath);
			return Response.ok(f).build();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return Response.status(404).build();
	}

	@GET
	@Path("{hypertext}")
	@Produces("text/html")
	public Response getRequestedFile(@PathParam("hypertext") String filepath) {
		if(filepath.contains("admin/")) return Response.status(403).build();
		try {
			String f = getfile(filepath);
			return Response.ok(f).build();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return Response.status(404).build();
	}


	@POST
	@Path("book")
	@Produces("text/html")
	public Response postBookingData(
			@FormParam("name") String name,
			@FormParam("phone") String phone,
			@FormParam("dateFrom") String dateFrom,
			@FormParam("dateTo") String dateTo,
			@FormParam("numPeople") int n,
			@FormParam("class") int qual,
			@FormParam("bRoomService") boolean roomserv) {
		Booking b = new Booking();
		
		b.setName(name);
		b.setN_rooms(n);
		b.setPhone(phone);
		b.setDateFrom(dateFrom);
		b.setDateTo(dateTo);
		b.setQual(Booking.QualityClass.get(qual));
		b.setRoomService(roomserv);
		
		bookings.add(b);
		try {
			return Response.seeOther(new URI("hotel/menuBookAccept.html")).build();
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@POST
	@Path("admin")
	@Produces("text/html")
	public Response postLoginInfo(
			@FormParam("username") String name,
			@FormParam("password") String password
			) throws URISyntaxException {
		if(name.equals("Valeri") && password.equals("madara1233")) {

			logged_in = true;
			return Response.seeOther(new URI("hotel/admin/admin.html")).build();
		}
		return Response.status(403).entity("You're not allowed in here!").build();
	}
	
	@GET
	@Path("admin/admin.html")
	@Produces("text/plain")
	public Response getAdminPage() {
		if(!logged_in) return Response.status(403).entity("YOU SHALL NOT PASS!").build();
		if(bookings.size() == 0 ) return Response.ok("There are no bookings").build();
		StringBuilder sb = new StringBuilder("We have these bookings:\n");
		for(Booking b : bookings) {
			sb.append(b.toString() + "\n");
		}
		return Response.ok(sb.toString()).build();
	}
}
